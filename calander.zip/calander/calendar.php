<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<link href="calendar.css" type="text/css" rel="stylesheet" />
<body>
<?php
include 'calendar_det.php';
 
$calendar = new Calendar();
 
echo $calendar->show();
?>
</body>
</html>

   